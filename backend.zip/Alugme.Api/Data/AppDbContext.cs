
using Microsoft.EntityFrameworkCore;
using Alugme.Api.Domain;

namespace Alugme.Api.Data;

public class AppDbContext : DbContext {
  public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) {}

  public DbSet<User> Users => Set<User>();
  public DbSet<Profile> Profiles => Set<Profile>();
  public DbSet<UserRole> UserRoles => Set<UserRole>();
  public DbSet<Property> Properties => Set<Property>();
  public DbSet<Landlord> Landlords => Set<Landlord>();
  public DbSet<BankAccount> BankAccounts => Set<BankAccount>();
  public DbSet<Rental> Rentals => Set<Rental>();
  public DbSet<RentalContract> RentalContracts => Set<RentalContract>();
  public DbSet<Inspection> Inspections => Set<Inspection>();
  public DbSet<InspectionPhoto> InspectionPhotos => Set<InspectionPhoto>();
  public DbSet<Banner> Banners => Set<Banner>();

  protected override void OnModelCreating(ModelBuilder b){
    b.Entity<User>().HasIndex(x=>x.Email).IsUnique();
    b.Entity<UserRole>().HasIndex(x=>new{ x.UserId, x.Role}).IsUnique();
    b.Entity<Profile>().HasOne(p=>p.User).WithOne(u=>u.Profile).HasForeignKey<Profile>(p=>p.UserId);
  }
}
