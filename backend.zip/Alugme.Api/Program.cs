
using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Alugme.Api.Data;
using Alugme.Api.Auth;
using Alugme.Api.Domain;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<AppDbContext>(o=>
  o.UseSqlServer(builder.Configuration.GetConnectionString("Default")));

builder.Services.AddScoped<JwtTokenService>();
builder.Services.AddControllers();

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
.AddJwtBearer(o=>{
  o.TokenValidationParameters = new TokenValidationParameters{
    ValidateIssuer=true, ValidateAudience=true, ValidateLifetime=true,
    ValidIssuer=builder.Configuration["Jwt:Issuer"],
    ValidAudience=builder.Configuration["Jwt:Audience"],
    IssuerSigningKey=new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]!))
  };
});

builder.Services.AddAuthorization();

builder.Services.AddSwaggerGen(c=>{
  c.SwaggerDoc("v1", new OpenApiInfo{ Title="Alugme API", Version="v1"});
  c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme{
    Name="Authorization", Type=SecuritySchemeType.Http, Scheme="bearer", BearerFormat="JWT", In=ParameterLocation.Header
  });
  c.AddSecurityRequirement(new OpenApiSecurityRequirement{
    { new OpenApiSecurityScheme{ Reference=new OpenApiReference{ Type=ReferenceType.SecurityScheme, Id="Bearer"}}, new string[]{} }
  });
});

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

// Seed admin
using(var scope = app.Services.CreateScope()){
  var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
  db.Database.Migrate();
  if(!db.Users.Any()){
    var admin = new User{
      Email="admin@admin.com",
      PasswordHash=BCrypt.Net.BCrypt.HashPassword("123456")
    };
    admin.Roles.Add(new UserRole{ Role=AppRole.Admin});
    admin.Profile = new Profile{ Name="Admin", Email=admin.Email };
    db.Users.Add(admin);
    db.SaveChanges();
  }
}

app.Run();

public partial class Program {}
