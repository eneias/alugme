
using System.ComponentModel.DataAnnotations.Schema;

namespace Alugme.Api.Domain;

public class User {
  public Guid Id { get; set; } = Guid.NewGuid();
  public string Email { get; set; } = null!;
  public string PasswordHash { get; set; } = null!;
  public bool Active { get; set; } = true;
  public Profile Profile { get; set; } = null!;
  public ICollection<UserRole> Roles { get; set; } = new List<UserRole>();
}

public class Profile {
  public Guid Id { get; set; } = Guid.NewGuid();
  public Guid UserId { get; set; }
  public string Name { get; set; } = null!;
  public string Email { get; set; } = null!;
  public string? Phone { get; set; }
  public string? Photo { get; set; }
  public bool Status { get; set; } = true;
  public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
  public DateTime LastAccess { get; set; } = DateTime.UtcNow;
  public User User { get; set; } = null!;
}

public class UserRole {
  public Guid Id { get; set; } = Guid.NewGuid();
  public Guid UserId { get; set; }
  public AppRole Role { get; set; }
  public User User { get; set; } = null!;
}

public class Property {
  public Guid Id { get; set; } = Guid.NewGuid();
  public string Name { get; set; } = null!;
  public string Address { get; set; } = null!;
  public string Neighborhood { get; set; } = null!;
  public string City { get; set; } = null!;
  public decimal Price { get; set; }
  public int Bedrooms { get; set; }
  public int Bathrooms { get; set; }
  public decimal Area { get; set; }
  public PropertyAvailability Availability { get; set; } = PropertyAvailability.Available;
  public Guid LandlordId { get; set; }
  public User Landlord { get; set; } = null!;
  public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
  public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
}

public class Landlord {
  public Guid Id { get; set; } = Guid.NewGuid();
  public Guid UserId { get; set; }
  public bool SocialContractAccepted { get; set; }
  public DateTime? SocialContractAcceptedAt { get; set; }
  public bool Validated { get; set; }
  public User User { get; set; } = null!;
}

public class BankAccount {
  public Guid Id { get; set; } = Guid.NewGuid();
  public Guid LandlordId { get; set; }
  public string Bank { get; set; } = null!;
  public string Agency { get; set; } = null!;
  public string Account { get; set; } = null!;
  public BankAccountType AccountType { get; set; } = BankAccountType.Corrente;
  public string HolderName { get; set; } = null!;
  public string HolderCpf { get; set; } = null!;
  public bool Validated { get; set; }
  public Landlord Landlord { get; set; } = null!;
}

public class Rental {
  public Guid Id { get; set; } = Guid.NewGuid();
  public Guid PropertyId { get; set; }
  public Guid? TenantId { get; set; }
  public DateTime StartDate { get; set; }
  public DateTime EndDate { get; set; }
  public ContractStatus Status { get; set; } = ContractStatus.Active;
  public Property Property { get; set; } = null!;
  public User? Tenant { get; set; }
}

public class RentalContract {
  public Guid Id { get; set; } = Guid.NewGuid();
  public Guid RentalId { get; set; }
  public Guid PropertyId { get; set; }
  public Guid? TenantId { get; set; }
  public string TenantName { get; set; } = null!;
  public decimal MonthlyRent { get; set; }
  public DateTime StartDate { get; set; }
  public DateTime EndDate { get; set; }
  public ContractStatus Status { get; set; } = ContractStatus.Active;
}

public class Inspection {
  public Guid Id { get; set; } = Guid.NewGuid();
  public Guid PropertyId { get; set; }
  public InspectionType Type { get; set; }
  public InspectionStatus Status { get; set; } = InspectionStatus.PendingTenant;
  public bool Locked { get; set; }
  public string? Observations { get; set; }
  public Property Property { get; set; } = null!;
  public ICollection<InspectionPhoto> Photos { get; set; } = new List<InspectionPhoto>();
}

public class InspectionPhoto {
  public Guid Id { get; set; } = Guid.NewGuid();
  public Guid InspectionId { get; set; }
  public string Url { get; set; } = null!;
  public string? Description { get; set; }
  public UploadedByType UploadedBy { get; set; } = UploadedByType.Landlord;
  public Inspection Inspection { get; set; } = null!;
}

public class Banner {
  public Guid Id { get; set; } = Guid.NewGuid();
  public string Title { get; set; } = null!;
  public string ImageUrl { get; set; } = null!;
  public bool Active { get; set; } = true;
  public int Order { get; set; }
}
